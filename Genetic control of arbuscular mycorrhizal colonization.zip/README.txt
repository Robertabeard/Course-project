The following data accompanies Stahlhut et al. 2021 - "Genetic control of arbuscular mycorrhizal colonization by Rhizophagus intraradices in Helianthus annuus (L.)"

DataS1.csv - Root colonization data used for genome-wide association mapping. All metrics reflect percent of root length colonized with arbuscular mycorrhizal fungi. Mean Colonization Rate (LS Mean) is the least squares mean of root colonization for each line (genotype) when corrected for spatial gradients in the greenhouse. Maximum Colonization is the highest colonization rate of the four biological replicates of each line. Range of Colonization represents the difference in colonization rate between the biological replicate with the highest colonization rate and the lowest colonization rate for each line. The Inclusion in GWAS column indicates the lines that were included in genome-wide association analysis, after 27 lines were excluded due to high residual heterozygosity.

DataS2.csv - Above-ground dry biomass and nutrient concentrations in dried plant tissues, measured
using Inductively-Coupled Plasma Mass Spectrometry (ICP-MS) for the Core 12 lines. 'Sample
Number' refers to the unique identifier given to each sample. An asterisk next to the sample
number indicates that the sample had to be pooled with other replicates due to low biomass. All
pooled individuals are listed with that sample. 'Line Number' refers to the genotype number
within the sunflower association mapping panel. 'USDA Ames Number' refers to the accession
number with the USDA North Central Regional Plant Introduction Station in Ames, Iowa.
'Derived from USDA or INRA Accession' refers to the USDA or INRA accession from which
the genotype is derived via single-seed descent (see Mandel et al., 2011). 'Treatment' refers to
whether the individual was inoculated by AM fungi (I, inoculated) or not (C, control). 'Bench'
refers to the bench, equivalent to a replicate block, in which each individual was located. 'Aboveground
dried biomass' is the dry shoot mass of each individual (grams). The nutrients analyzed
were aluminum (Al), boron (B), calcium (Ca), copper (Cu), iron (Fe), magnesium (Mg),
manganese (Mn), molybdeum (Mo), phosphorus (P), potassium (K), sodium (Na), sulfur (S), and
zinc (Zn), presented as indicated in either ppm or % of dry mass. Missing data are indicated with "NA".

DataS3.csv - List of all genes within significant and suggestive regions. Colocate.block is the
identifier for the linkage block containing each gene. Start and End indicate the position of the
gene on each chromosome within the HA412-HO genome assembly v.2 (Temme et al. 2020).
Locus_tag is the unique identifier for the gene within the HA412-HO genome assembly v.2.
Product is the expected product as annotated by Todesco et al. 2020. Ontology_term lists all
gene ontology (GO) terms associated with that gene. Chromosome indicates the linkage group on
which each gene can be found.

Supporting Information.pdf (on Zenodo) - Dataset legends, supplemental figures, and supplemental methods.